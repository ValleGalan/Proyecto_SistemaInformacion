//CODIGO USANDO JQUERY
$(document).ready(function(){

    //AGREGO CLASE filtro_activo AL PRIMER FILTRO ---------------
    $('.filtros .categoria[category="todos"]').addClass('filtro_activo');
    var filtros = [' ',' ',' '];
    
    //FILTRANDO DEPORTES -------------------------------------------
    $('.categoria').click(function(){
        var catfiltro = $(this).attr('category');
        var esta = false;
        
        filtros.forEach(function(element) {
            if (element==catfiltro) {
                esta = true;
            }
        });

        //CAMBIO LA CLASE filtro_activo AL NUEVO FILTRO SELECCIONADO -------------
        $('.categoria[category="todos"]').removeClass('filtro_activo');
        if (esta==false){
            if(catfiltro=='Terrestre'||catfiltro=='Acuatico'||catfiltro=='Aereo'){
                $('.categoria[category="Terrestre"]').removeClass('filtro_activo');
                $('.categoria[category="Aereo"]').removeClass('filtro_activo');
                $('.categoria[category="Acuatico"]').removeClass('filtro_activo');
                filtros[0] = catfiltro;
                $(this).addClass('filtro_activo');
            }
            if(catfiltro=='Joven'||catfiltro=='Adulto'||catfiltro=='Adulto_mayor'){
                $('.categoria[category="Joven"]').removeClass('filtro_activo');
                $('.categoria[category="Adulto"]').removeClass('filtro_activo');
                $('.categoria[category="Adulto_mayor"]').removeClass('filtro_activo');
                filtros[1] = catfiltro;
                $(this).addClass('filtro_activo');
            }
            if(catfiltro=='Bajo'||catfiltro=='Medio'||catfiltro=='Alto'){
                $('.categoria[category="Bajo"]').removeClass('filtro_activo');
                $('.categoria[category="Medio"]').removeClass('filtro_activo');
                $('.categoria[category="Alto"]').removeClass('filtro_activo');
                filtros[2] = catfiltro;
                $(this).addClass('filtro_activo');
            }
            //const cantidad = filtros.push(catfiltro);
        }
        
        if (esta==true){
            $(this).removeClass('filtro_activo');            
            if(catfiltro=='Terrestre'||catfiltro=='Acuatico'||catfiltro=='Aereo'){
                filtros[0] = ' ';
            }
            if(catfiltro=='Joven'||catfiltro=='Adulto'||catfiltro=='Adulto_mayor'){
                filtros[1] = ' '
            }
            if(catfiltro=='Bajo'||catfiltro=='Medio'||catfiltro=='Alto'){
                filtros[2] = ' '
            }
        }


        //OCULTAR DEPORTES ---------------------------------------------
        $('.deporte').css('transform', 'scale(0)');
        function ocultar_deporte(){
            $('.deporte').hide();
        } setTimeout(ocultar_deporte,400);

        //MOSTRAR DEPORTES ---------------------------------------------
        function mostrar_deporte(){
            if(filtros[0]==' '&&filtros[1]==' '&&filtros[2]==' '){
                //MOSTRAR TODOS LOS DEPORTES ---------------------------------------
                $('.filtros .categoria[category="todos"]').addClass('filtro_activo');
                function mostrar_todo(){
                    $('.deporte').show();
                    $('.deporte').css('transform', 'scale(1)');
                } setTimeout(mostrar_todo,400);
                
            }
            else{
                filtros.forEach(function(element){
                    
                    $('.deporte[categoria1="'+element+'"]').show();
                    $('.deporte[categoria1="'+element+'"]').css('transform', 'scale(1)');
                    $('.deporte[categoria2="'+element+'"]').show();
                    $('.deporte[categoria2="'+element+'"]').css('transform', 'scale(1)');
                    $('.deporte[categoria3="'+element+'"]').show();
                    $('.deporte[categoria3="'+element+'"]').css('transform', 'scale(1)');    
                });
            };
        } setTimeout(mostrar_deporte,400);
    });

    //MOSTRAR TODOS LOS DEPORTES ---------------------------------------
    $('.categoria[category="todos"]').click(function(){

        filtros = [];
        $('.categoria').removeClass('filtro_activo');
        $(this).addClass('filtro_activo');

        function mostrar_todo(){
            $('.deporte').show();
            $('.deporte').css('transform', 'scale(1)');
        } setTimeout(mostrar_todo,400);
        
    });

});


//GESTION DE DEPORTES-------------------------------------------------------
$(document).ready(function(){
    const btnEliminacion = document.querySelectorAll(".btnEliminacion");

    btnEliminacion.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const confirmacion = confirm('¿Seguro de eliminar el deporte?');
            if(!confirmacion) {
                e.preventDefault();
            }
        });
    });
});

//DESVANECER ALERTA-----------------------------------------
window.setTimeout(function(){
    $(".alert").fadeTo(1000, 0).slideDown(1000, function(){
        $(this).remove();
    });
}, 2000);