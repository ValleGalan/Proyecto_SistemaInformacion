from django.db import models
from django.db.models.base import Model

# Create your models here.
import datetime
import os

def rutaArchivo(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('imagenes/', filename)

class Deporte(models.Model):
    nombre = models.CharField(max_length=25)
    ambiente = models.CharField(max_length=10)
    edad = models.CharField(max_length=20)
    riesgo = models.CharField(max_length=10)
    imagen = models.ImageField(upload_to=rutaArchivo, null=True, blank=True)
    enlace = models.CharField(max_length=150, null=True)

    